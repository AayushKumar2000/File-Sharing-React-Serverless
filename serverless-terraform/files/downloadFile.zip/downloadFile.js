const AWS = require("aws-sdk");
const s3 = new AWS.S3({ signatureVersion: "v4" });
const bucketName = "filesharing2000";
const expirationInSeconds =120;
const lambda = new AWS.Lambda();
const DynamoDb=new AWS.DynamoDB.DocumentClient({region:'us-east-1'});

exports.handler =  (event, context,callback) => {
    
     
       const fId=event.queryStringParameters.fid;
    // const fId="1602526193898";
  


 //   Params object for creating the 
    const params = {
        Bucket: bucketName,
        Key: fId,
        Expires: expirationInSeconds
    };
    


// to check the no downloads

 const params3={
      TableName: "file_details",
     Key:{
         "fileID": ""+fId 
      }
  };
  
  
  const params2={
      TableName: "file_details",
        Key:{
         "fileID": ""+fId
      },
     UpdateExpression: "set currentDownloads = currentDownloads + :val",
    ExpressionAttributeValues:{
        ":val": 1
    },
    ReturnValues:"UPDATED_NEW"

  };
  
 
 DynamoDb.get(params3, function(err,data){
   
     if(!err){
         
          
         if(data.Item.currentDownloads <  data.Item.totalDownloads){
          
          
          
           DynamoDb.update(params2,function (err,data){
                

      if(!err){
          (async ()=>{
            // Creating the presigned Url
                    const preSignedURL = await s3.getSignedUrl("getObject", params);
            
          
          const returnObject = {
            statusCode: 200,
            headers: {
                "access-control-allow-origin": "*"
            },
            body: JSON.stringify({
                 fileDownloadURL: preSignedURL,

            })
         };
        callback(null,returnObject);
        })();
          
        
          
          
          
      }
       
      
  });
         

     }
     }
 })


    

        
       
   
};