const AWS = require("aws-sdk");
const DynamoDb=new AWS.DynamoDB.DocumentClient({region:'us-east-1'});

exports.handler =  (event, context,callback) => {
    console.log(event.body);
    const x=JSON.parse(event.body);
    console.log(x);
    const params={
        TableName:"file_details",
        Key:{"fileID":""+x.id},
         ExpressionAttributeNames:{"#a":"zipFileDetails"},
         UpdateExpression: 'set #a = :x',
        
       
         ExpressionAttributeValues:{":x":x.data}
    };
    console.log(params);
    
    const returnObject = {
            statusCode: 200,
            headers: {
                "access-control-allow-origin": "*"
            },
           
        };
    
    DynamoDb.update(params,(err,data)=>{
        if(err)
         {
             console.log(err);
             callback(err);
             
         }else
         {
             callback(null,returnObject);
         }
    });
};

