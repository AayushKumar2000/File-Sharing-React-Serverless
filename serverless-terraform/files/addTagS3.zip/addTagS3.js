const AWS = require("aws-sdk");
const s3 = new AWS.S3({ signatureVersion: "v4" });
const DynamoDb=new AWS.DynamoDB.DocumentClient({region:'us-east-1'});


exports.handler =(event, context,callback) => {
    // TODO implement
  //  console.log(event.Records[0].s3.object.key);
    
   const fId=event.Records[0].s3.object.key;
   // const fId="160291706430";
    
    
     const params={
      TableName: "file_details",
     Key:{
         "fileID": ""+fId 
      }
  };
    
    
    DynamoDb.get(params, function(err,data){
        
        if(!err){
              var params = {
              Bucket: "filesharing2000", 
              Key: fId, 
              Tagging: {
                TagSet: [
                  {
                    Key: "expireValue", 
                    Value: data.Item.expireValue
                  }
                      ]
                  }
              };
              
               s3.putObjectTagging(params, function(err, data) {
     
                if(err)
                 console.log(err);
               });
            
        }
        
    })
    
    

 

 
};


